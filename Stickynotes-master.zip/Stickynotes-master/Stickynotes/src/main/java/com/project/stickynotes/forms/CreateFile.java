/**
 * 
 */
package com.project.stickynotes.forms;

/**
 * @author Varun
 *
 */
public class CreateFile {
	
	private String filecontents;
	private String newName;
	private String filePath;
	/**
	 * @return the filecontents
	 */
	public String getFilecontents() {
		return filecontents;
	}
	/**
	 * @param filecontents the filecontents to set
	 */
	public void setFilecontents(String filecontents) {
		this.filecontents = filecontents;
	}
	/**
	 * @return the newName
	 */
	public String getNewName() {
		return newName;
	}
	/**
	 * @param newName the newName to set
	 */
	public void setNewName(String newName) {
		this.newName = newName;
	}
	/**
	 * @return the filePath
	 */
	public String getFilePath() {
		return filePath;
	}
	/**
	 * @param filePath the filePath to set
	 */
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
}
