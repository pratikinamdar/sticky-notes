/**
 * 
 */
package com.project.stickynotes.forms;

/**
 * @author Varun
 *
 */
public class LoginForm {
	
	private String appUsername;
	private String appPassword;
	
	/**
	 * @return the appUsername
	 */
	public String getAppUsername() {
		return appUsername;
	}
	/**
	 * @param appUsername the appUsername to set
	 */
	public void setAppUsername(String appUsername) {
		this.appUsername = appUsername;
	}
	/**
	 * @return the appPassword
	 */
	public String getAppPassword() {
		return appPassword;
	}
	/**
	 * @param appPassword the appPassword to set
	 */
	public void setAppPassword(String appPassword) {
		this.appPassword = appPassword;
	}
	
}
